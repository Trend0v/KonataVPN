// Слушаем сообщения от popup.js для управления системным прокси
browser.runtime.onMessage.addListener(async (message) => {
  if (message.action === "enable_proxy") {
    try {
      // Маршрутизируем трафик через локальный SOCKS5 прокси Clash/Mihomo (127.0.0.1:7890)
      await browser.proxy.settings.set({
        value: {
          proxyType: "manual",
          socks: "127.0.0.1:7890",
          socksVersion: 5,
          proxyDNS: true
        },
        scope: "regular"
      });
      console.log("KonataVPN: Proxy enabled -> 127.0.0.1:7890");
      return { success: true };
    } catch (err) {
      console.error("KonataVPN: Failed to enable proxy", err);
      return { success: false, error: err.message };
    }
  } else if (message.action === "disable_proxy") {
    try {
      // Сбрасываем настройки прокси браузера на системные дефолты
      await browser.proxy.settings.clear({ scope: "regular" });
      console.log("KonataVPN: Proxy disabled");
      return { success: true };
    } catch (err) {
      console.error("KonataVPN: Failed to disable proxy", err);
      return { success: false, error: err.message };
    }
  }
});
