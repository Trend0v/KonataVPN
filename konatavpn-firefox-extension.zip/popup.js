document.addEventListener("DOMContentLoaded", async () => {
  const toggle = document.getElementById("proxy-toggle");
  const statusBadge = document.getElementById("status-badge");

  // Загружаем текущее сохранённое состояние прокси
  let state;
  try {
    state = await browser.storage.local.get("proxy_enabled");
  } catch (e) {
    state = { proxy_enabled: false };
  }
  
  const enabled = !!state.proxy_enabled;
  toggle.checked = enabled;
  updateUI(enabled);

  // Слушаем изменение переключателя
  toggle.addEventListener("change", async () => {
    const isChecked = toggle.checked;
    
    try {
      await browser.storage.local.set({ proxy_enabled: isChecked });
    } catch (e) {
      // Игнорируем ошибки хранилища
    }
    
    updateUI(isChecked);

    if (isChecked) {
      // Отправляем команду в background.js на включение прокси
      await browser.runtime.sendMessage({ action: "enable_proxy" });
    } else {
      // Отправляем команду в background.js на отключение прокси
      await browser.runtime.sendMessage({ action: "disable_proxy" });
    }
  });

  // Функция для динамического обновления элементов интерфейса
  function updateUI(enabled) {
    if (enabled) {
      statusBadge.textContent = "ПОДКЛЮЧЕН";
      statusBadge.className = "status-badge connected";
    } else {
      statusBadge.textContent = "ОТКЛЮЧЕН";
      statusBadge.className = "status-badge disconnected";
    }
  }
});
